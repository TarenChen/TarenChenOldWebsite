function runCode(){
    alert("Hi! Thanks for visiting. My website is still in development and not completely mobile friendly.");
}